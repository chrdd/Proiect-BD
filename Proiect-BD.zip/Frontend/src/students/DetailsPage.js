// src/students/DetailsPage.js
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const DetailsPage = () => {
  const { id } = useParams();
  const [student, setStudent] = useState(null);

  useEffect(() => {
    axios.get(`/api/students/${id}`)
      .then(response => {
        setStudent(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the student!', error);
      });
  }, [id]);

  if (!student) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>{student.name}</h1>
      <p>Age: {student.age}</p>
      <p>Email: {student.email}</p>
      <Link to={`/edit-student/${student.id}`}>Edit</Link>
    </div>
  );
}

export default DetailsPage;
